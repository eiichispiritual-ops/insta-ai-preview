#!/bin/sh
set -eu
# インスタAI：外のフォルダを読まない設定を ~/insta-ai に入れる（既存の設定は消さずに足す）
S="$(cd "$(dirname "$0")" && pwd)"; W="${INSTA_AI_SETUP_DIR:-$HOME/insta-ai}"
mkdir -p "$W/.claude" "$W/.codex" || exit 1
T="$W/.claude/settings.json"
if [ ! -s "$T" ]; then cp "$S/claude-settings.json" "$T"
elif command -v osascript >/dev/null 2>&1; then
  osascript -l JavaScript - "$T" "$S/claude-settings.json" <<'JS' >/dev/null || { echo "設定の合成に失敗しました"; exit 1; }
function run(a){ObjC.import('Foundation');
function rd(p){return JSON.parse($.NSString.stringWithContentsOfFileEncodingError(p,$.NSUTF8StringEncoding,null).js)}
var o=rd(a[0]),n=rd(a[1]);o.permissions=o.permissions||{};var p=o.permissions,q=n.permissions;
for(var k in q){if(k==='deny'){var d=p.deny||[];q.deny.forEach(function(x){if(d.indexOf(x)<0)d.push(x)});p.deny=d}else p[k]=q[k]}
$(JSON.stringify(o,null,2)).writeToFileAtomicallyEncodingError(a[0],true,$.NSUTF8StringEncoding,null)}
JS
elif command -v python3 >/dev/null 2>&1 && python3 -c 1 >/dev/null 2>&1; then
  python3 - "$T" "$S/claude-settings.json" <<'PY' || { echo "設定の合成に失敗しました"; exit 1; }
import json,sys
o=json.load(open(sys.argv[1]));n=json.load(open(sys.argv[2]))
p=o.setdefault('permissions',{})
for k,v in n['permissions'].items():
    if k=='deny':
        d=p.setdefault('deny',[]);d+= [x for x in v if x not in d]
    else: p[k]=v
json.dump(o,open(sys.argv[1],'w'),ensure_ascii=False,indent=2)
PY
else echo "既存の .claude/settings.json があるため、設定を足せませんでした。ここで止めて、表示された文章を確認してください。" >&2; exit 1; fi
C="$W/.codex/config.toml"
if [ ! -s "$C" ]; then cp "$S/codex-config.toml" "$C"
else
  H=""; grep -q '^ *sandbox_mode' "$C" || H="sandbox_mode = \"workspace-write\""
  grep -q '^ *approval_policy' "$C" || H="$H
approval_policy = \"on-request\""
  { printf '%s\n' "$H"; cat "$C"; grep -q '^\[sandbox_workspace_write\]' "$C" || printf '\n[sandbox_workspace_write]\nnetwork_access = false\n'; } > "$C.tmp" && mv "$C.tmp" "$C"
fi
for f in AGENTS.md CLAUDE.md; do
  if [ ! -f "$W/$f" ]; then cp "$S/$f" "$W/$f"
  elif ! grep -q 'インスタAI 作業フォルダのルール' "$W/$f"; then { echo; cat "$S/$f"; } >> "$W/$f"; fi
done
echo "安全設定：OK"
echo "この表示は設定ファイルの配置完了です。起動したAIの権限設定は、アプリの画面でも確認してください。"
